#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/TypeId.h>
#include <NsCore/Package.h>
#include <NsGui/MatrixTransform.h>
#include <NsGui/Grid.h>
#include <NsMath/Transform.h>
#include <NsMath/Constants.h>


using namespace Noesis;
using namespace Noesis::Core;
using namespace Noesis::Gui;
using namespace Noesis::Math;


class MyTouch: public Grid
{
public:
    void OnManipulationInertiaStarting(const ManipulationInertiaStartingEventArgs& e)
    {
        e.desiredTranslationDeceleration = 100.0f / (1000.0f * 1000.0f);
        e.desiredRotationDeceleration = 360.0f / (1000.0f * 1000.0f);
        e.desiredExpansionDeceleration = 300.0f / (1000.0f * 1000.0f);
        e.handled = true;
    }
    
    void OnManipulationDelta(const ManipulationDeltaEventArgs& e)
    {
        UIElement* rectangle = NsStaticCast<UIElement*>(e.source);
        MatrixTransform* tr = NsStaticCast<MatrixTransform*>(rectangle->GetRenderTransform());
        Transform2f matrix = tr->GetMatrix();

        matrix.RotateAt(e.deltaManipulation.rotation * DegToRad_f, e.manipulationOrigin.x,
            e.manipulationOrigin.y);
        matrix.ScaleAt(e.deltaManipulation.scale, e.deltaManipulation.scale, 
            e.manipulationOrigin.x, e.manipulationOrigin.y);
        matrix.Translate(e.deltaManipulation.translation.x, e.deltaManipulation.translation.y);
 
        tr->SetMatrix(matrix);
        e.handled = true;
    }

private:
     NS_IMPLEMENT_INLINE_REFLECTION(MyTouch, Grid)
     {
        NsMeta<TypeId>("MyTouch");
     }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C" NS_DLL_EXPORT
void NsRegisterReflection(ComponentFactory* factory, NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(MyTouch)
}
